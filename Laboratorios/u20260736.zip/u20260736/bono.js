import readline from 'node:readline';

const bono = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

bono.question(`Ingrese la cantidad de dias: `, (dias) => {
    let dias_totales = parseInt(dias);
    let pagoNormal = 10.00
    let acumuladora_pago = 0;

    for (let i = 1; i <= dias_totales; i++) {
        if (i % 3 === 0) {
            let pagoConBono = pagoNormal + 5.00;
            acumuladora_pago += pagoConBono; 
            console.log(`Dia ${i}: recibe bono. Pago: $${pagoConBono.toFixed(2)}`);
        } else {
            acumuladora_pago += pagoNormal;
            console.log(`Dia ${i}: pago normal de: $${pagoNormal.toFixed(2)}`);
        }
    }
    console.log(`Pago total acumulado: $${acumuladora_pago.toFixed(2)}`);
    bono.close();
});