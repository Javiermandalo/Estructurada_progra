import readline from 'node:readline';

const saldo = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

saldo.question(`¿Cuántos días utilizará el servicio? (ej: 1 a 10): `, (dias) => {
    let diasss = parseInt(dias);
    let GB = 20;

    for (let i = 1; i <= diasss; i++) {
        GB -= 2; 
        console.log(`Día ${i}: quedan ${GB} GB.`);
        if (GB <= 4) {
            console.log(`Saldo bajo.`);
        }
    }
    saldo.close();
});